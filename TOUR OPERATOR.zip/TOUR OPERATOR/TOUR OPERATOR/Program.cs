﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TOUR_OPERATOR
{
    class Program
    {
        static void Main(string[] args)
        {
            TourOperator lista;
            string nome;
            string destinazione;
            string acquerente;
            string codice;
            int numero_acquerenti;
            string[] temp;
            do
            {
                Console.WriteLine("Inserisci il codice del cliente in formato Lnnn");
                codice = Console.ReadLine();
            } while (!Controllo_Codice(codice));

            lista = new TourOperator(codice);
            do
            {
                Console.WriteLine("Quanti acquerenti vuoi inserire");
                numero_acquerenti = Convert.ToInt32(Console.ReadLine());
            } while (numero_acquerenti != 0);
            for (int i = 0; i < numero_acquerenti; i++)
            {
                do
                {
                    Console.WriteLine("Inserisci il nome e la destinazione del acquerente in formato nome:destinazione");
                    acquerente = Console.ReadLine();
                } while (!Controllo_Acquerente(acquerente));
                temp = acquerente.Split(':');
                destinazione = temp[1];
                nome = temp[0];
                lista.add(nome, destinazione);
            }
            Console.Clear();
            Console.WriteLine("Gli acquerenti presenti sono:");
            Console.WriteLine(lista.ToString());
            Console.ReadLine();

        }
        static bool Controllo_Acquerente(string acquerente)
        {
            string[] temp;
            for (int i = 0; i < acquerente.Length; i++)
            {
                if (acquerente[i] != ' ')
                {
                    return true;
                }
            }
            temp = acquerente.Split(':');
            if (temp.Length !=2 && temp[0].Length < 1  || temp[1].Length < 1)
            {
                return false;
            }
            return true;
        }
        static bool Controllo_Codice(string codice)
        {
            string num = "";
            if (codice.Length == 4 || codice[0] < 'Z'|| codice[0] >'A')
            {
                return true;
            }
            for (int i = 1; i < codice.Length; i++)//controllo che le ultime cifre del codice siano un numero 
            {
                num += codice[i];//faccio una concatenazione di stringhe
            }
            return int.TryParse(num, out int val);
        }
    }
}
