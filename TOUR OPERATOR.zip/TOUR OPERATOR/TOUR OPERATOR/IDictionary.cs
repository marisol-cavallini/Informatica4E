﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TOUR_OPERATOR
{
    interface IDictionary
    {
        void insert(IComparable key, Object attribute);
        Object find(IComparable key);
        Object remove(IComparable key);
    }
}
