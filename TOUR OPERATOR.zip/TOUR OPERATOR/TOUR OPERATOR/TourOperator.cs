﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TOUR_OPERATOR
{
    public class TourOperator : IContainer, IDictionary
    {
        string nextClientCode;
        Dictionary<IComparable, object> dizionario = new Dictionary<IComparable, object>();//creo il mio dizionario 

        public TourOperator(string initialClientCode)
        {
            nextClientCode = initialClientCode;//assegno al mio cliente il codice digitato 
        }
        public void add(string nome, string destinazione)
        {
            Client acquerente = new Client(nome, destinazione);//creo il mio acquerente 
            dizionario.Add(nextClientCode, acquerente);//aggiungo il mio acquerente al mio dizionario 
            Codice_Successivo(nextClientCode);//metodo per incrementare il codice 
        }
        private class Client// serve per attribuire al nostro acquerente il nome e la sua destinazione nel nostro dizionario 
        {
            string name; // nome del cliente
            string dest; // destinazione del viaggio
            public Client(string aName, string aDest)
            {
                name = aName;
                dest = aDest;
            }
            public string Name { get => name; }
            public string Dest { get => dest; }
        }
        private class Coppia : IComparable//sereve per verificare se ci sono presenti più acquerenti con lo stesso codice 
        {
            string code;
            Client client;
            public Coppia(string aCode, Client aClient)
            {
                code = aCode;
                client = aClient;
            }
            public int CompareTo(object obj)
            {
                return code.CompareTo(obj);
            }
        }
        public override string ToString()//per stampare a video il mio acquerente => codice:nome:destinazione
        {
            string acquerente = "";
            foreach (var item in dizionario)
            {
                Client acq= (Client)item.Value;
                acquerente += $"{item.Key}:{acq.Name}:{acq.Dest}\n";
            }
            return acquerente;
        }
         //implemento i metodi della interfacia IContainer
         public bool isEmpty()
         {
            if (dizionario.Count==0)//controllo se il mio dizionario è vuoto 
            {
                return true;
            }
            return false;
         }
        public void makeEmpty()
        {
            dizionario.Clear();//svuoto il mio dizionario
        }
        public int size()
        {
            return dizionario.Count;//mostra quanti elementi sono presenti nel mio dizionario 
        }
        //implemento i metodi della interfacia IDictionary
        public void insert(IComparable key, Object attribute)
        {
            string temp = (string)attribute;
            string[] cliente = temp.Split(':');
            bool codice_uguale = false;
            Client c1 = new Client(cliente[0], cliente[1]);
            Coppia coppia = new Coppia((string)key, c1);
            foreach (var item in dizionario)
            {
                if (coppia.CompareTo(item.Key)==0)
                {
                    codice_uguale = true;
                }
            }
            if (codice_uguale==true)
            {
                dizionario.Add(key, c1);//se non esite lo vado ad aggiungere alla collezione 
            }
            else
            {
                dizionario[key] = c1;// se esiste invece lo sovrascrivo
            }
        }
        public object find(IComparable key)
        {
            try
            {
                Client acq1 = (Client)dizionario[key];//vado a cercarlo
                return $"{acq1.Name} : {acq1.Dest}";
            }
            catch (Exception)
            {

                throw new Exception("codice non trovato");
            }
        }
        public object remove(IComparable key)
        {
            try
            {
                Client acq2 = (Client)dizionario[key];//vado a cercare il codice nella raccolta 
                dizionario.Remove(key);//dopo lo rimuovo 
                return $"{acq2.Name} : {acq2.Dest}";
            }
            catch (Exception)
            {

                throw new Exception("codice non trovato");
            }
        }
        private void Codice_Successivo(string code)
        {
            char lettera = code[0];//vado ad assegnare la lettera presente nella posizuone 0
            string numeri="";
            int numero;
            for (int i = 1; i < code.Length; i++)
            {
                numeri += code[i];             
            }
            numero = Convert.ToInt32(numeri);//converto il la stringa in un numero 
            numero++;//lo incremento 
            if (numero == 999)//se vedo che il numero è uguale a 999
            {
                lettera++;//incremento la lettera 
                numero = 000;// e metto il numero a 000
            }
            nextClientCode = lettera + Convert.ToString(numero);//dopo vado ad assegnarlo al cliente successivo 
        }
       
    }
}
    

