﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TOUR_OPERATOR
{
    interface IContainer
    {
        bool isEmpty();
        void makeEmpty();
        int size();
    }
}
